<?php
// Página de inicio: presentación del sitio y accesos a cada sección.
require_once __DIR__ . '/includes/config.php';

$pagina = [
    'titulo'      => 'Sauripedia | La enciclopedia de dinosaurios en español',
    'descripcion' => 'Sauripedia es una enciclopedia de dinosaurios en español: especies, hábitats, dietas, mundo prehistórico y un quiz interactivo para poner a prueba lo que sabes.',
    'ruta'        => '',
    'seccion'     => 'inicio',
    'css'         => ['inicio.css'],
    'scripts'     => ['fondo_dinos.js'],
    'json_ld'     => [
        '@context'    => 'https://schema.org',
        '@type'       => 'WebSite',
        'name'        => SITIO_NOMBRE,
        'url'         => SITIO_URL,
        'inLanguage'  => 'es',
        'description' => 'Enciclopedia de dinosaurios en español con información didáctica e interactiva.',
    ],
];

// Tarjetas de la portada: texto propio de cada sección (la ruta sale de SECCIONES)
$apartados = [
    'dinosaurios' => 'Descubre el fascinante mundo de los dinosaurios y sus diferentes especies. Aprende sobre sus hábitats, dietas y comportamientos.',
    'mundo'       => 'Explora cómo era la Tierra en la era de los dinosaurios y recorre los distintos períodos geológicos.',
    'quiz'        => '¿Cuánto sabes sobre los dinosaurios? Pon a prueba tus conocimientos con preguntas de tres niveles de dificultad.',
    'comentarios' => 'Deja un comentario sobre el sitio o sus contenidos y ayúdanos a mejorar el proyecto.',
];

// ------------------------------------------------------------
// LÍNEA DEL TIEMPO
// Todo se mide en "Ma" = millones de años atrás. La línea va del pasado (izquierda)
// al presente (derecha): empieza en 252 Ma (inicio del Triásico) y termina en 66 Ma
// (extinción de los dinosaurios no avianos).
// ------------------------------------------------------------
$ma_inicio = 252;
$ma_final  = 66;

// Las tres eras (en realidad son períodos de la Era Mesozoica) con su fecha de inicio y de fin
$eras = [
    'triasico'  => ['nombre' => 'Triásico',  'desde' => 252, 'hasta' => 201],
    'jurasico'  => ['nombre' => 'Jurásico',  'desde' => 201, 'hasta' => 145],
    'cretacico' => ['nombre' => 'Cretácico', 'desde' => 145, 'hasta' => 66],
];

// Dinosaurios conocidos: [id de la ficha, aparición (Ma), desaparición (Ma)].
// Las fechas son aproximadas: los científicos las ajustan con cada hallazgo.
$especies_tiempo = [
    ['eoraptor',       231, 229],
    ['coelophysis',    216, 203],
    ['plateosaurus',   214, 204],
    ['dilophosaurus',  193, 183],
    ['stegosaurus',    155, 150],
    ['alosaurio',      155, 145],
    ['diplodocus',     154, 152],
    ['iguanodon',      126, 122],
    ['utahraptor',     126, 124],
    ['spinosaurus',     99,  94],
    ['giganotosaurus',  99,  97],
    ['velociraptor',    75,  71],
    ['triceratops',     68,  66],
    ['tyrannosaurus',   68,  66],
];

$ancho_etiqueta = 16.0; // % del ancho de la línea que ocupa cada etiqueta (imagen + nombre)
$separacion     = 0.8;  // aire entre una barra y su etiqueta (en %)

/** Pasa "millones de años atrás" a un porcentaje horizontal (0 % = 252 Ma, 100 % = 66 Ma). */
$posicion = static fn(float $ma): float => ($ma_inicio - $ma) / ($ma_inicio - $ma_final) * 100;

/** Número con punto decimal para usarlo dentro de un style="" (sin depender del idioma del servidor). */
$num = static fn(float $n): string => number_format($n, 2, '.', '');

// Posición y ancho de cada era sobre la línea
foreach ($eras as $clave => $era) {
    $eras[$clave]['izq']   = $posicion($era['desde']);
    $eras[$clave]['ancho'] = $posicion($era['hasta']) - $posicion($era['desde']);
}

// Cada dinosaurio va en un "carril" (fila). Se usa el primer carril donde no se pise
// con otro dinosaurio: así los que vivieron en épocas distintas comparten fila y la línea queda más baja.
$carriles = [];
$hitos    = [];
foreach ($especies_tiempo as [$id, $desde, $hasta]) {
    $ficha = dinosaurio($id);
    if ($ficha === null) {
        continue; // si falta la ficha en el JSON, simplemente no se dibuja
    }

    $izq   = $posicion($desde);
    $ancho = max($posicion($hasta) - $izq, 1.0); // las existencias muy cortas igual se ven
    $der   = $izq + $ancho;

    // La etiqueta va a la derecha de la barra; si no entra (extremo derecho), va a la izquierda
    $lado  = ($der + $separacion + $ancho_etiqueta <= 100) ? 'der' : 'izq';
    $ocupa = $lado === 'der'
        ? [$izq, $der + $separacion + $ancho_etiqueta]
        : [$izq - $separacion - $ancho_etiqueta, $der];

    $carril = 0;
    while (true) {
        $choca = false;
        foreach ($carriles[$carril] ?? [] as [$a, $b]) {
            if ($ocupa[0] < $b + 0.5 && $ocupa[1] > $a - 0.5) {
                $choca = true;
                break;
            }
        }
        if (!$choca) {
            break;
        }
        $carril++;
    }
    $carriles[$carril][] = $ocupa;

    $hitos[] = [
        'ficha'  => $ficha,
        'desde'  => $desde,
        'hasta'  => $hasta,
        'izq'    => $izq,
        'ancho'  => $ancho,
        'lado'   => $lado,
        'carril' => $carril,
        'era'    => $desde > 201 ? 'triasico' : ($desde > 145 ? 'jurasico' : 'cretacico'),
    ];
}
$total_carriles = max(count($carriles), 1);

// ------------------------------------------------------------
// FONDO ANIMADO: imágenes que usará fondo_dinos.js (solo las que se ven bien grandes y livianas)
// ------------------------------------------------------------
$imagenes_fondo = [];
foreach (dinosaurios() as $ficha) {
    $img   = $ficha['imagen'];
    $ruta  = __DIR__ . '/imagenes/' . $img['archivo'];
    $razon = $img['ancho'] / max($img['alto'], 1);
    if ($img['ancho'] >= 500 && $img['alto'] >= 250 && $razon >= 0.9 && $razon <= 2.4
        && is_file($ruta) && filesize($ruta) <= 135000) {
        $imagenes_fondo[] = url('imagenes/' . $img['archivo']);
    }
}

require __DIR__ . '/includes/cabecera.php';
?>
            <section class="panel bienvenida">
                <h1>La Sauripedia: enciclopedia de dinosaurios</h1>
                <p>La Sauripedia reúne información sobre <?= count(dinosaurios()) ?> especies de dinosaurios y reptiles prehistóricos, organizada de manera didáctica e interactiva, con el fin de expandir el conocimiento sobre estos fascinantes animales.</p>
            </section>

            <section class="contenedor_apartados" aria-label="Secciones del sitio">
<?php foreach ($apartados as $clave => $texto): ?>
                <article class="panel apartado">
                    <h2><a href="<?= url(SECCIONES[$clave]['ruta']) ?>"><?= e(SECCIONES[$clave]['titulo']) ?></a></h2>
                    <p><?= e($texto) ?></p>
                </article>
<?php endforeach; ?>
            </section>
            <section class="panel linea_tiempo" aria-labelledby="titulo_tiempo">
                <h2 id="titulo_tiempo">Línea del tiempo de los dinosaurios</h2>
                <p class="tl_intro">Los dinosaurios dominaron la Tierra durante tres períodos. Cada barra muestra cuándo vivió una especie y el punto marca su aparición. <abbr title="millones de años atrás">Ma</abbr> = millones de años atrás.</p>

                <div class="tl_desplazable" tabindex="0" role="region" aria-label="Línea del tiempo, se desplaza hacia los costados en pantallas chicas">
                    <div class="tl_contenido">
                        <!-- Encabezado: los tres períodos, con el ancho proporcional a lo que duraron -->
                        <div class="tl_eras">
<?php foreach ($eras as $clave => $era): ?>
                            <div class="tl_era era_<?= $clave ?>" style="--ancho: <?= $num($era['ancho']) ?>">
                                <strong><?= e($era['nombre']) ?></strong>
                                <span><?= $era['desde'] ?> – <?= $era['hasta'] ?> Ma</span>
                            </div>
<?php endforeach; ?>
                        </div>

                        <!-- Pista: una lista ordenada por aparición; cada dinosaurio es una barra + su etiqueta -->
                        <ol class="tl_pista" style="--carriles: <?= $total_carriles ?>">
<?php foreach ($eras as $clave => $era): ?>
                            <li class="tl_fondo_era era_<?= $clave ?>" style="--izq: <?= $num($era['izq']) ?>; --ancho: <?= $num($era['ancho']) ?>" aria-hidden="true"></li>
<?php endforeach; ?>
<?php foreach ($hitos as $hito):
    $ficha = $hito['ficha'];
    $mini  = $ficha['miniatura'];
?>
                            <li class="tl_dino era_<?= $hito['era'] ?>" style="--izq: <?= $num($hito['izq']) ?>; --ancho: <?= $num($hito['ancho']) ?>; --carril: <?= $hito['carril'] ?>">
                                <span class="tl_barra" aria-hidden="true"></span>
                                <a class="tl_etiqueta tl_<?= $hito['lado'] ?>" href="<?= url(ruta_dinosaurio($ficha['id'])) ?>">
                                    <img src="<?= url('imagenes/' . $mini['archivo']) ?>" alt=""
                                         width="<?= (int) $mini['ancho'] ?>" height="<?= (int) $mini['alto'] ?>" loading="lazy" decoding="async">
                                    <span class="tl_texto">
                                        <span class="tl_nombre"><?= e($ficha['nombre']) ?></span>
                                        <span class="tl_rango"><?= $hito['desde'] ?> – <?= $hito['hasta'] ?> Ma</span>
                                    </span>
                                </a>
                            </li>
<?php endforeach; ?>
                        </ol>

                        <!-- Regla con las fechas que separan los períodos -->
                        <div class="tl_regla" aria-hidden="true">
                            <span class="tl_marca tl_marca_ini" style="--izq: 0">252 Ma</span>
                            <span class="tl_marca" style="--izq: <?= $num($posicion(201)) ?>">201 Ma</span>
                            <span class="tl_marca" style="--izq: <?= $num($posicion(145)) ?>">145 Ma</span>
                            <span class="tl_marca tl_marca_fin" style="--izq: 100">66 Ma</span>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Datos para el fondo animado (lo dibuja fondo_dinos.js; sin JavaScript simplemente no se ve) -->
            <div id="fondo_dinos_datos" hidden data-imagenes="<?= e(json_encode($imagenes_fondo, JSON_UNESCAPED_SLASHES)) ?>"></div>
<?php require __DIR__ . '/includes/pie.php'; ?>
