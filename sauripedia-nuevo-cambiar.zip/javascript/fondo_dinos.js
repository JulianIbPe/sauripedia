// ============================================================
// fondo_dinos.js
// Fondo animado de la portada: dinosaurios con los bordes difuminados que
// aparecen, se deslizan despacio por un costado y se desvanecen.
//
// Hay dos "escenarios": uno en el costado izquierdo y otro en el derecho.
// En cada escenario las imágenes van y vienen entre dos puntos:
//   1) una imagen aparece en el punto A y avanza hacia el punto B;
//   2) cerca de B se desvanece y, en ese mismo lugar, aparece otra
//      que avanza hacia A (el lado contrario);
//   3) y así sigue, con una imagen distinta cada vez.
// Las imágenes las manda index.php en el atributo data-imagenes.
// El movimiento y los fundidos los hace CSS (animación fondo-deriva en inicio.css).
// ============================================================
(function () {
    'use strict';

    var datos = document.getElementById('fondo_dinos_datos');
    if (!datos) {
        return;
    }

    // Quien pidió "menos movimiento" en su sistema no ve el fondo animado
    if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
        return;
    }

    var imagenes;
    try {
        imagenes = JSON.parse(datos.getAttribute('data-imagenes') || '[]');
    } catch (error) {
        return;
    }
    if (!Array.isArray(imagenes) || imagenes.length === 0) {
        return;
    }

    // ---------- Ajustes (se pueden tocar para cambiar el efecto) ----------
    var DURACION_MS = 18000;   // cuánto dura cada imagen en pantalla (más alto = más lento)
    var SOLAPE      = 0.8;     // la siguiente aparece al 80 % de la vida de la anterior
    var OPACIDAD    = 0.6;     // 1 = totalmente visible
    var RECORRIDO   = 14;      // cuánto avanza cada imagen, en vw (1 vw = 1 % del ancho de pantalla)

    // Cada escenario: x1 y x2 son los puntos A y B (posición izquierda de la imagen, en vw);
    // y es la altura (en vh) y "retraso" evita que los dos escenarios cambien al mismo tiempo.
    var escenarios = [
        { x1: -9, x2: -9 + RECORRIDO, y: 8,  retraso: 0,                      yendo: true },
        { x1: 83, x2: 83 - RECORRIDO, y: 42, retraso: DURACION_MS * SOLAPE / 2, yendo: true }
    ];

    // ---------- Capa que contiene las imágenes ----------
    var capa = document.createElement('div');
    capa.className = 'fondo_dinos';
    capa.setAttribute('aria-hidden', 'true');
    document.body.appendChild(capa);

    // Orden aleatorio (Fisher-Yates) para que cada visita muestre los dinosaurios en otro orden
    for (var i = imagenes.length - 1; i > 0; i--) {
        var j = Math.floor(Math.random() * (i + 1));
        var tmp = imagenes[i];
        imagenes[i] = imagenes[j];
        imagenes[j] = tmp;
    }
    var indice = 0;

    function siguienteImagen() {
        var url = imagenes[indice];
        indice = (indice + 1) % imagenes.length;
        return url;
    }

    // Con la pestaña oculta se pausa la animación (y no se crean imágenes nuevas)
    document.addEventListener('visibilitychange', function () {
        capa.classList.toggle('pausado', document.hidden);
    });

    function lanzar(escenario) {
        if (document.hidden) {
            window.setTimeout(function () { lanzar(escenario); }, 1000);
            return;
        }

        var img = new Image();
        img.className = 'fondo_dino';
        img.alt = '';
        img.decoding = 'async';

        // Se agrega a la capa recién cuando terminó de cargar: así nunca "aparece de golpe"
        img.onload = function () {
            var desde = escenario.yendo ? escenario.x1 : escenario.x2;
            var hasta = escenario.yendo ? escenario.x2 : escenario.x1;

            img.style.setProperty('--x', desde + 'vw');
            img.style.setProperty('--y', escenario.y + 'vh');
            img.style.setProperty('--ancho', 'clamp(240px, 26vw, 460px)');
            img.style.setProperty('--duracion', DURACION_MS + 'ms');
            img.style.setProperty('--opacidad', OPACIDAD);
            img.style.setProperty('--desplazamiento', (hasta - desde) + 'vw');

            // Al terminar su recorrido se quita del documento
            img.addEventListener('animationend', function () {
                img.remove();
            });

            capa.appendChild(img);

            // La próxima imagen sale del lado contrario, en el mismo lugar donde esta se desvanece
            escenario.yendo = !escenario.yendo;
            window.setTimeout(function () { lanzar(escenario); }, DURACION_MS * SOLAPE);
        };

        // Si una imagen no carga, se prueba con la siguiente
        img.onerror = function () {
            window.setTimeout(function () { lanzar(escenario); }, 200);
        };

        img.src = siguienteImagen();
    }

    escenarios.forEach(function (escenario) {
        window.setTimeout(function () { lanzar(escenario); }, escenario.retraso + 300);
    });
})();
